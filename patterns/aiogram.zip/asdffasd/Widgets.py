# import shutil
# import zipfile
# import os
# from PyQt5 import uic  # Импортируем uic
# from PyQt5.QtWidgets import QMainWindow, QWidget, QFileDialog, QInputDialog, \
#     QMessageBox, QRadioButton
# from PyQt5.QtSql import QSqlDatabase, QSqlTableModel
# from app import db

# class MainWindow(QMainWindow):
#     def __init__(self):
#         super().__init__()
#         uic.loadUi('Qt_handlers\\ui_files\\pattern_manager.ui', self)  # Загружаем дизайн
#         self.initUI()

#     def initUI(self):
#         db = QSqlDatabase.addDatabase('QSQLITE')
#         # Укажем имя базы данных
#         db.setDatabaseName('database.db')
#         # И откроем подключение
#         db.open()
#         self.model = QSqlTableModel(self, db)
#         self.model.setTable('patterns')
#         self.model.select()
#         self.edit_widg = TableEdit()
#         self.pattern_table.setModel(self.model)
#         self.pattern_table.setColumnWidth(0, 176)
#         self.pattern_table.setColumnWidth(1, 177)
#         self.create_button.clicked.connect(self.create_pattern)
#         self.table_update_button.clicked.connect(self.update_table)
#         self.edit_table_button.clicked.connect(self.show_table_edit)
#         self.create_folder_button.clicked.connect(self.open_choice_widget)

#     def create_pattern(self):
#         pattern_name, ok_pressed  =  QInputDialog.getText(self, "Insert pattern name", 
#                                                 "What will the pattern name be?")
#         if pattern_name not in db.sql_get_pattern_names(db) and pattern_name.strip() != '':
#             if ok_pressed:
#                 fname = QFileDialog.getOpenFileName(self, 'Выбратьz zip папку', '', '(*.zip)')[0]
#                 # добавить проверку на ориг директорию
#                 if fname not in db.sql_get_pattern_directorys(db) and fname.strip() != '':
#                     file_zip = zipfile.ZipFile(f'patterns\\{pattern_name}.zip', 'w')

#                     shutil.copy(fname, f'patterns\\{pattern_name}.zip')
#                     file_zip.close()
#                     db.sql_add_pattern(db, pattern_name, f'patterns/{pattern_name}.zip', fname)
#                     self.model.select()
#                     self.pattern_table.setModel(self.model)
#                     self.pattern_table.setColumnWidth(0, 176)
#                     self.pattern_table.setColumnWidth(1, 177)
#                     self.notify_lable.setText("""Pattern successfully made!""")
#                 else:
#                     self.notify_lable.setText('Pattern by this directory aleady exists')

#         elif pattern_name:
#             self.notify_lable.setText('This name is invalid or already taken. Please choose another')

#     def update_table(self):
#         self.model.select()
#         self.pattern_table.setModel(self.model)
#         self.pattern_table.setColumnWidth(0, 176)
#         self.pattern_table.setColumnWidth(1, 177)
#         self.notify_lable.setText('Table updated') 

#     def show_table_edit(self):
#         self.edit_widg.update_table()  
#         self.edit_widg.show()

#     def open_choice_widget(self):
#         self.choice_widg = ChoiceWidget()
#         for pattern_name in db.sql_get_pattern_names(db):
#             self.choice_widg.button = QRadioButton(self)
#             self.choice_widg.button.toggled.connect(self.choice_widg.choose_pattern)
#             self.choice_widg.button.text = pattern_name
#             self.choice_widg.button.setText(pattern_name)
#             self.choice_widg.button.setStyleSheet('color: white;')
#             self.choice_widg.choicewidget_layout.addWidget(self.choice_widg.button)
#         self.choice_widg.show()



# class AuthWidget(QWidget):
#     def __init__(self):
#         super().__init__()
#         uic.loadUi('Qt_handlers\\ui_files\\auth_widget.ui', self)
#         self.initUI()

#         self.signin_button.clicked.connect(self.auth)
#         self.signup_button.clicked.connect(self.register)
#         self.login = self.login_lineedit
#         self.passcode = self.passcode_lineedit
#         self.mainwin = MainWindow()

#     def check_info(self):
#         if self.login.text() == '':
#             return False
#         if self.passcode.text() == '':
#             return False
#         return True

#     def register(self):
#         if self.check_info():
#             login = self.login.text()
#             passcode = self.passcode.text()
#             id = len(db.sql_get_users(db)) + 1
#             if login not in db.sql_get_users_logins(db):
#                 db.sql_add_user(db, login, id, passcode)
#                 self.start_lable.setText('Successfully registered!')
#                 self.mainwin.show()
#                 self.hide()
#             else:
#                 self.start_lable.setText('login is busy, please use another')

#     def auth(self):
#         if self.check_info():
#             login = self.login.text()
#             passcode = self.passcode.text()
#             if login in db.sql_get_users_logins(db) and passcode == db.sql_get_user_passcode(db, login):
#                 self.start_lable.setText('Successfully authorised!')
#                 self.mainwin.show()
#                 self.hide()
#             else:
#                 self.start_lable.setText('Wrong data, please try again')


#     def initUI(self):
#         pass


# class TableEdit(QWidget):
#     def __init__(self):
#         super().__init__()
#         uic.loadUi(r'Qt_handlers\ui_files\table_edit.ui', self)
#         self.initUI()
    
#     def initUI(self):
#         self.db = QSqlDatabase.addDatabase('QSQLITE')
#         self.db.setDatabaseName('database.db')
#         self.db.open()
#         self.model = QSqlTableModel(self, self.db)
#         self.model.setTable('patterns')
#         self.model.select()
#         self.pattern_table.setModel(self.model)
#         self.pattern_table.setColumnWidth(0, 265)
#         self.pattern_table.setColumnWidth(1, 265)
#         self.delete_button.clicked.connect(self.delete_item)
#         self.drop_button.clicked.connect(self.drop_table)
#         self.update_button.clicked.connect(self.update_table)

#     def delete_item(self):
#         pattern = self.query_lineedit.text()
#         msgbox = QMessageBox()
#         msgbox.setStyleSheet("color: white;")
#         valid = msgbox.question(
#             self, '', f"Are you sure you want to delete this item: {pattern}",
#             QMessageBox.Yes, QMessageBox.No)
#         # Если пользователь ответил утвердительно, выполняем запрос. 
#         # Не забываем зафиксировать изменения
#         if valid == QMessageBox.Yes:
#             try:
#                 os.remove(f'patterns/{pattern}.zip')
#                 db.sql_remove_pattern(db, pattern)
#                 self.model.setTable('patterns')
#                 self.model.select()
#                 self.pattern_table.setModel(self.model)
#                 self.pattern_table.setColumnWidth(0, 265)
#                 self.pattern_table.setColumnWidth(1, 265)
#             except Exception:
#                 self.table_edit_lable.setText('Failed to complete the query')
            

#     def drop_table(self):
#         msgbox = QMessageBox()
#         msgbox.setStyleSheet("color: white;")
#         valid = msgbox.question(
#             self, '', f"Are you sure you want to drop whole table?",
#             QMessageBox.Yes, QMessageBox.No)
#         if valid == QMessageBox.Yes:
#             for direct in db.sql_get_pattern_directorys(db):
#                 os.remove(direct)
#             db.sql_drop_table(db, 'patterns')
#             self.model.setTable('patterns')
#             self.model.select()
#             self.pattern_table.setModel(self.model)
#             self.pattern_table.setColumnWidth(0, 265)
#             self.pattern_table.setColumnWidth(1, 265)

#     def update_table(self):
#         self.model.select()
#         self.pattern_table.setModel(self.model)
#         self.pattern_table.setColumnWidth(0, 265)
#         self.pattern_table.setColumnWidth(1, 265)
#         self.table_edit_lable.setText('Table updated') 


# class ChoiceWidget(QWidget):
#     def __init__(self):
#         super().__init__()
#         uic.loadUi(r'Qt_handlers\ui_files\choice_widget.ui', self)
#         self.initUI()

#     def initUI(self):
#         self.pattern_choose_button.clicked.connect(self.choose_pattern)

#     def choose_pattern(self):
#         res = self.sender()
#         if res.isChecked():
#             print(res.text)