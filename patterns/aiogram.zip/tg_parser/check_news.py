import requests
from bs4 import BeautifulSoup
import json


def get_first_news():
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0'
    }

    url = 'https://knife.media'
    response = requests.get(url=url, headers=headers)

    soup = BeautifulSoup(response.text, 'lxml')
    articles = soup.findAll('div', class_='unit--triple')
    articles_dict = {}

    for article in articles:
        article_title = article.find('a', class_='unit__content-link').text.strip()
        article_url = article.find('a', class_='unit__content-link').get('href') 
        article_id = article_url.split('/')[-2]
        articles_dict[article_id] = {
            'article_title': article_title,
            'article_url': article_url,
        }
    
    with open('articles_dict.json', 'w') as file:
        json.dump(articles_dict, file, indent=4, ensure_ascii=False)
    
def check_articles_update():
    with open('articles_dict.json') as file:
        articles_dict = json.load(file)

    fresh_news = {}    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0'
    }

    url = 'https://knife.media'
    response = requests.get(url=url, headers=headers)

    soup = BeautifulSoup(response.text, 'lxml')
    articles = soup.findAll('div', class_='unit--triple')
    
    for article in articles:
        article_url = article.find('a', class_='unit__content-link').get('href') 
        article_id = article_url.split('/')[-2]

        if article_id in articles_dict:
            continue
        else:
            article_title = article.find('a', class_='unit__content-link').text.strip()
            articles_dict[article_id] = {
            'article_title': article_title,
            'article_url': article_url,
            }
            
        fresh_news[article_id] = {
            'article_title': article_title,
            'article_url': article_url,
        }

    with open('articles_dict.json', 'w') as file:
        json.dump(articles_dict, file, indent=4, ensure_ascii=False)

    return fresh_news


def main():
    # get_first_news()
    check_articles_update()

if __name__ == '__main__':
    main()
