import requests
from bs4 import BeautifulSoup
from config import TOKEN

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0'
}

proxies = {}

def get_location(url):
    response = requests.get(url=url, headers=headers, proxies=proxies)
    soup = BeautifulSoup(response.text, 'lxml')

    ip = soup.find('div', class_='ip').text.strip()
    place = soup.find('div', class_='value-country').text.strip()
    print(f'Your IP: {ip}\nYour location: {place}')


def main():
    get_location(url='https://2ip.ru')


if __name__ == '__main__':
    main()