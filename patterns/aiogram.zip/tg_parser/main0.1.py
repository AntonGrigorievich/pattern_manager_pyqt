import asyncio
from aiogram import Bot, executor, Dispatcher, types
from config import TOKEN, user_id
import json
from aiogram.dispatcher.filters import Text
from check_news import check_articles_update

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands='start')
async def start(message: types.Message):
    start_buttons = ['Все новости', 'Последние 3 новости', 'Свежие новости']
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(*start_buttons)
    
    await message.answer('Лента новостей', reply_markup=keyboard)

@dp.message_handler(Text(equals='Все новости'))
async def get_all_news(message: types.Message):
    with open('articles_dict.json') as file:
        articles_dict = json.load(file)

    for k, v in list(articles_dict.items()):
        news = f"{v['article_url']}"
        await message.answer(news)

@dp.message_handler(Text(equals='Последние 3 новости'))
async def get_last_three(message: types.Message):
    with open('articles_dict.json') as file:
        articles_dict = json.load(file)

    for k, v in list(articles_dict.items())[-3:]:
        news = f"{v['article_url']}"
        await message.answer(news)

@dp.message_handler(Text(equals='Свежие новости'))
async def get_fresh_news(message: types.Message):
    fresh_news = check_articles_update()
    if len(fresh_news) >= 1:
        for k, v in sorted(fresh_news.items()):
            news = f"{v['article_url']}"
            await message.answer(news)
    else:
        await message.answer('Пока новых новостей не появилось')

async def regular_update_check():
    while True:
        fresh_news = check_articles_update()

        if len(fresh_news) >= 1:
            for k, v in sorted(fresh_news.items()):
                news = f"{v['article_url']}"
                await bot.send_message(user_id, news)
        else:
            await bot.send_message(user_id, 'Пока ничего нового', disable_notification=True)

        await asyncio.sleep(7200)

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.create_task(regular_update_check())
    executor.start_polling(dp)