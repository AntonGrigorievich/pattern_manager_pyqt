import requests
from bs4 import BeautifulSoup
import time
from settings import currencys
from googlesheets import GoogleSheet

class Currency:
    markets_urls = [
        'https://www.gate.io/ru/price',
        'https://www.bitget.com/en/markets'
 ]
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:104.0) Gecko/20100101 Firefox/104.0'}

    current_converted_price = 0

    gateio_dict = {}

    def __init__(self):
        self.current_converted_price = self.get_currency_price()

    def get_currency_price(self):
        gateio_page = requests.get(self.markets_urls[0], headers=self.headers)
        soup = BeautifulSoup(gateio_page.content, 'html.parser')

        gateio_values = [''.join(v.text.split('\n')) for v in soup.findAll("td", {"class": "ant-table-cell"})]
        gateio_names = [n[:3] for n in gateio_values[0::8]]
        gateio_prices = [float(v[1:]) for v in gateio_values[1::8]]
        gateio_currencies_info = [(gateio_names[n], gateio_prices[n]) for n in range(len(gateio_names))]
        for cur in gateio_currencies_info:
            if cur[0] not in self.gateio_dict.keys():
                self.gateio_dict[cur[0]] = [cur[1], 0]
            else:
                if self.gateio_dict[cur[0]][0] != cur[1]:
                    percent = (self.gateio_dict[cur[0]][0] - cur[1]) / (self.gateio_dict[cur[0]][0] / 100)
                    self.gateio_dict[cur[0]] = [cur[1], round(percent, 4)]
        

        bitget_page = requests.get(self.markets_urls[1], headers=self.headers)
        soup = BeautifulSoup(bitget_page.content, 'html.parser')
        bitget_values = [value.text for value in soup.findAll("div", {"class": "grid-right"})]
        return bitget_values

    def check_currency(self):
#   for cur in range(len())  
        currency = self.get_currency_price()
        # if currency >= self.current_converted_price:
        #     print("Курс вырос")
        # elif currency <= self.current_converted_price:
        #     print("Курс упал")

#   print(self.get_currency_price())
        print(self.get_currency_price())
        print()
        time.sleep(180)
        self.check_currency()

currency = Currency()
print(currency.check_currency())