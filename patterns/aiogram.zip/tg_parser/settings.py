# Связка валют
currencys = []

