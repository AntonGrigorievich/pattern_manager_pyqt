from aiogram import Dispatcher, types
from config import CHANNEL_TG_ID
from main import bot
from config import Admin_id, CHANNEL_ID, CHANNEL_URL
from callback_data import check_callback
from time import sleep

dp = Dispatcher(bot)

kb = types.InlineKeyboardMarkup(row_width=2)
to_sub = types.InlineKeyboardButton(text='Подписаться', url=CHANNEL_URL)
subed = types.InlineKeyboardButton(text='Я подписался', callback_data=check_callback.new())
kb.insert(to_sub)
kb.insert(subed)

@dp.message_handler(commands='start')
async def startup_alert(message: types.Message):
    await bot.send_message(chat_id=Admin_id, text='Bot is up')

@dp.message_handler()
async def if_subed(message: types.Message):
    id_user = message.from_user.id
    print(id_user)
    if id_user != CHANNEL_TG_ID:
        user_channel_status = await bot.get_chat_member(chat_id=CHANNEL_ID, user_id=id_user)
        print(user_channel_status)
        if user_channel_status['status'] != 'left':
            pass
        else:
            await message.delete()
            await message.answer(text='Приветствую тебя!\nЧтобы иметь возможность писать в чат, необходимо подписаться на канал. После подписки, нажмите на кнопку "Я подписался"', reply_markup=kb)
            

@dp.callback_query_handler(text_contains='check')
async def if_subed_callback(call: types.CallbackQuery):
    user_channel_status = await bot.get_chat_member(chat_id=CHANNEL_ID, user_id=call.from_user.id)
    print(user_channel_status)
    if user_channel_status['status'] != 'left':
        # pass
        await call.message.answer(text='Теперь вы можете пользоваться чатом')
    else:
        await call.message.answer(text='Вы все еще не подписаны', reply_markup=kb)
