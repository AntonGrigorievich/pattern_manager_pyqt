from aiogram import Bot, executor
from config import TOKEN

bot = Bot(token=TOKEN, parse_mode='HTML')


if __name__ == '__main__':
    from handlers import startup_alert, dp
    executor.start_polling(dp, on_startup=startup_alert)