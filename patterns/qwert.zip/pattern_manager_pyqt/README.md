# pattern_manager_pyqt
Yandex lyceum project
